import os
import json
import re
from typing import Dict, Text, Any, List
import logging
from dateutil import parser
import sqlalchemy as sa
import sqlite3
from numpy import random
import actions.mysql as mysql

import twilio
from twilio.rest import Client

import pymongo

import spacy
import en_core_web_sm
import nltk
from nltk.corpus import wordnet
from bltk.langtools import PosTagger
from bltk.langtools import Tokenizer

import datetime
from rasa_sdk.events import ReminderScheduled

#Global variable is here
#-----------------------------------------------------
nlp = en_core_web_sm.load()
nlu = spacy.load("en_core_web_sm")

GlobalList = []
flag = False
#-----------------------------------------------------

from rasa_sdk.events import SlotSet, AllSlotsReset, Restarted, UserUtteranceReverted, FollowupAction, ActionReverted, UserUttered, Form

from rasa_sdk.interfaces import Action
from rasa_sdk.events import (
    SlotSet,
    EventType,
    ActionExecuted,
    SessionStarted,
    Restarted,
    FollowupAction,
    UserUtteranceReverted,
    AllSlotsReset,
)
from rasa_sdk import Tracker, FormValidationAction
from rasa_sdk.executor import CollectingDispatcher

from actions.parsing import (
    parse_duckling_time_as_interval,
    parse_duckling_time,
    get_entity_details,
    parse_duckling_currency,
)

from actions.profile_db import create_database, ProfileDB
from actions.rasa_db import create_database_rasa, rasaDB

from actions.custom_forms import CustomFormValidationAction
from rasa_sdk.types import DomainDict
from actions.converter import is_ascii, BnToEn_Word, BnToEn

db_manager = mysql.DBManager()
logger = logging.getLogger(__name__)

# The profile database is created/connected to when the action server starts
# It is populated the first time `ActionSessionStart.run()` is called.

PROFILE_DB_NAME = os.environ.get("PROFILE_DB_NAME", "profile")
PROFILE_DB_URL = os.environ.get("PROFILE_DB_URL", f"sqlite:///{PROFILE_DB_NAME}.db")
ENGINE = sa.create_engine(PROFILE_DB_URL)
create_database(ENGINE, PROFILE_DB_NAME)

profile_db = ProfileDB(ENGINE)

NEXT_FORM_NAME = {
    "pay_cc": "cc_payment_form",
    "transfer_money": "transfer_money_form",
    "search_transactions": "transaction_search_form",
    "check_earnings": "transaction_search_form",
}

FORM_DESCRIPTION = {
    "cc_payment_form": "credit card payment",
    "transfer_money_form": "money transfer",
    "transaction_search_form": "transaction search",
}


class ActionPayCC(Action):
    """Pay credit card."""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_pay_cc"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Executes the action"""
        print(tracker.latest_message['intent'].get('name'))

        slots = {
            "AA_CONTINUE_FORM": None,
            "zz_confirm_form": None,
            "credit_card": None,
            "account_type": None,
            "amount-of-money": None,
            "time": None,
            "time_formatted": None,
            "start_time": None,
            "end_time": None,
            "start_time_formatted": None,
            "end_time_formatted": None,
            "grain": None,
            "number": None,
        }

        if tracker.get_slot("zz_confirm_form") == "yes":
            credit_card = tracker.get_slot("credit_card")
            amount_of_money = float(tracker.get_slot("amount-of-money"))
            amount_transferred = float(tracker.get_slot("amount_transferred"))
            profile_db.pay_off_credit_card(
                tracker.sender_id, credit_card, amount_of_money
            )

            dispatcher.utter_message(response="utter_cc_pay_scheduled")

            slots["amount_transferred"] = amount_transferred + amount_of_money
        else:
            dispatcher.utter_message(response="utter_cc_pay_cancelled")

        return [SlotSet(slot, value) for slot, value in slots.items()]


class ValidatePayCCForm(CustomFormValidationAction):
    """Validates Slots of the cc_payment_form"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "validate_cc_payment_form"

    def amount_from_balance(
        self, dispatcher, tracker, credit_card_name, balance_type
    ) -> Dict[Text, Any]:
        amount_balance = profile_db.get_credit_card_balance(
            tracker.sender_id, credit_card_name, balance_type
        )
        account_balance = profile_db.get_account_balance(tracker.sender_id)
        if account_balance < float(amount_balance):
            dispatcher.utter_message(response="utter_insufficient_funds")
            return {"amount-of-money": None}
        
        return {
            "amount-of-money": f"{amount_balance:.2f}",
            "payment_amount_type": f"(your {balance_type})",
        }

    async def validate_amount_of_money(
        self,
        value: Text,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> Dict[Text, Any]:
        """Validates value of 'amount-of-money' slot"""
        if not value:
            return {"amount-of-money": None}

        account_balance = profile_db.get_account_balance(tracker.sender_id)
        # check if user asked to pay the full or the minimum balance
        if type(value) is str:
            credit_card_name = tracker.get_slot("credit_card")
            if credit_card_name:
                credit_card = profile_db.get_credit_card(
                    tracker.sender_id, credit_card_name
                )
            else:
                credit_card = None
            balance_types = profile_db.list_balance_types()
            if value and value.lower() in balance_types:
                balance_type = value.lower()
                if not credit_card:
                    dispatcher.utter_message(
                        f"I see you'd like to pay the {balance_type}."
                    )
                    return {"amount-of-money": balance_type}
                slots_to_set = self.amount_from_balance(
                    dispatcher, tracker, credit_card_name, balance_type
                )
                if float(slots_to_set.get("amount-of-money")) == 0:
                    dispatcher.utter_message(
                        response="utter_nothing_due", **slots_to_set
                    )
                    return {
                        "amount-of-money": None,
                        "credit_card": None,
                        "payment_amount_type": None,
                    }
                return slots_to_set

        try:
            entity = get_entity_details(
                tracker, "amount-of-money"
            ) or get_entity_details(tracker, "number")
            amount_currency = parse_duckling_currency(entity)
            if not amount_currency:
                raise TypeError
            if account_balance < float(amount_currency.get("amount-of-money")):
                dispatcher.utter_message(response="utter_insufficient_funds")
                return {"amount-of-money": None}
            return amount_currency
        except (TypeError, AttributeError):
            pass

        dispatcher.utter_message(response="utter_no_payment_amount")
        return {"amount-of-money": None}

    async def validate_credit_card(
        self,
        value: Text,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> Dict[Text, Any]:
        """Validates value of 'credit_card' slot"""
        if value and value.lower() in profile_db.list_credit_cards(tracker.sender_id):
            amount = tracker.get_slot("amount-of-money")
            credit_card_slot = {"credit_card": value.title()}
            balance_types = profile_db.list_balance_types()
            if amount and amount.lower() in balance_types:
                updated_amount = self.amount_from_balance(
                    dispatcher, tracker, value.lower(), amount
                )
                if float(updated_amount.get("amount-of-money")) == 0:
                    dispatcher.utter_message(
                        response="utter_nothing_due", **updated_amount
                    )
                    return {
                        "amount-of-money": None,
                        "credit_card": None,
                        "payment_amount_type": None,
                    }
                account_balance = profile_db.get_account_balance(tracker.sender_id)
                if account_balance < float(updated_amount.get("amount-of-money")):
                    dispatcher.utter_message(
                        response="utter_insufficient_funds_specific", **updated_amount
                    )
                    return {"amount-of-money": None}
                return {**credit_card_slot, **updated_amount}
            return credit_card_slot

        dispatcher.utter_message(response="utter_no_creditcard")
        return {"credit_card": None}

    async def explain_credit_card(
        self,
        value: Text,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> Dict[Text, Any]:
        """Explains 'credit_card' slot"""
        dispatcher.utter_message("You have the following credits cards:")
        for credit_card in profile_db.list_credit_cards(tracker.sender_id):
            current_balance = profile_db.get_credit_card_balance(
                tracker.sender_id, credit_card
            )
            dispatcher.utter_message(
                response="utter_credit_card_balance",
                **{
                    "credit_card": credit_card.title(),
                    "amount-of-money": f"{current_balance:.2f}",
                },
            )
        return {}

    async def validate_time(
        self,
        value: Text,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> Dict[Text, Any]:
        """Validates value of 'time' slot"""
        timeentity = get_entity_details(tracker, "time")
        parsedtime = timeentity and parse_duckling_time(timeentity)
        if not parsedtime:
            dispatcher.utter_message(response="utter_no_transactdate")
            return {"time": None}
        return parsedtime

    async def validate_zz_confirm_form(
        self,
        value: Text,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> Dict[Text, Any]:
        """Validates value of 'zz_confirm_form' slot"""
        if value in ["yes", "no"]:
            return {"zz_confirm_form": value}

        return {"zz_confirm_form": None}


class ActionTransactionSearch(Action):
    """Searches for a transaction"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_transaction_search"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        print(tracker.latest_message['intent'].get('name'))
        """Executes the action"""
        slots = {
            "AA_CONTINUE_FORM": None,
            "zz_confirm_form": None,
            "time": None,
            "time_formatted": None,
            "start_time": None,
            "end_time": None,
            "start_time_formatted": None,
            "end_time_formatted": None,
            "grain": None,
            "search_type": None,
            "vendor_name": None,
        }

        if tracker.get_slot("zz_confirm_form") == "yes":
            search_type = tracker.get_slot("search_type")
            deposit = search_type == "deposit"
            vendor = tracker.get_slot("vendor_name")
            vendor_name = f" at {vendor.title()}" if vendor else ""
            start_time = parser.isoparse(tracker.get_slot("start_time"))
            end_time = parser.isoparse(tracker.get_slot("end_time"))
            transactions = profile_db.search_transactions(
                tracker.sender_id,
                start_time=start_time,
                end_time=end_time,
                deposit=deposit,
                vendor=vendor,
            )

            aliased_transactions = transactions.subquery()
            total = profile_db.session.query(
                sa.func.sum(aliased_transactions.c.amount)
            )[0][0]
            if not total:
                total = 0
            numtransacts = transactions.count()
            slotvars = {
                "total": f"{total:.2f}",
                "numtransacts": numtransacts,
                "start_time_formatted": tracker.get_slot("start_time_formatted"),
                "end_time_formatted": tracker.get_slot("end_time_formatted"),
                "vendor_name": vendor_name,
            }

            dispatcher.utter_message(
                response=f"utter_searching_{search_type}_transactions",
                **slotvars,
            )
            dispatcher.utter_message(
                response=f"utter_found_{search_type}_transactions", **slotvars
            )
        else:
            dispatcher.utter_message(response="utter_transaction_search_cancelled")

        return [SlotSet(slot, value) for slot, value in slots.items()]


class ValidateTransactionSearchForm(CustomFormValidationAction):
    """Validates Slots of the transaction_search_form"""

    def name(self) -> Text:
        """Unique identifier of the form"""
        return "validate_transaction_search_form"

    async def run(
        self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        """Custom validates the filled slots"""
        events = await super().run(dispatcher, tracker, domain)

        # For 'spend' type transactions we need to know the vendor_name
        search_type = tracker.get_slot("search_type")
        if search_type == "spend":
            vendor_name = tracker.get_slot("vendor_name")
            if not vendor_name:
                events.append(SlotSet("requested_slot", "vendor_name"))

        return events

    async def validate_search_type(
        self,
        value: Text,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> Dict[Text, Any]:
        """Validates value of 'search_type' slot"""
        if value in ["spend", "deposit"]:
            return {"search_type": value}

        return {"search_type": None}

    async def validate_vendor_name(
        self,
        value: Text,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> Dict[Text, Any]:
        """Validates value of 'vendor_name' slot"""
        if value and value.lower() in profile_db.list_vendors():
            return {"vendor_name": value}

        dispatcher.utter_message(response="utter_no_vendor_name")
        return {"vendor_name": None}

    async def validate_time(
        self,
        value: Text,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> Dict[Text, Any]:
        """Validates value of 'time' slot"""
        timeentity = get_entity_details(tracker, "time")
        parsedinterval = timeentity and parse_duckling_time_as_interval(timeentity)
        if not parsedinterval:
            dispatcher.utter_message(response="utter_no_transactdate")
            return {"time": None}

        return parsedinterval


class ActionTransferMoney(Action):
    """Transfers Money."""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_transfer_money"

    async def run(
        self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        print(tracker.latest_message['intent'].get('name'))
        """Executes the action"""
        slots = {
            "AA_CONTINUE_FORM": None,
            "zz_confirm_form": None,
            "USERNAME": None,
            "amount-of-money": None,
            "number": None,
        }

        if tracker.get_slot("zz_confirm_form") == "yes":
            amount_of_money = float(tracker.get_slot("amount-of-money"))
            from_account_number = profile_db.get_account_number(
                profile_db.get_account_from_session_id(tracker.sender_id)
            )
            to_account_number = profile_db.get_account_number(
                profile_db.get_recipient_from_name(
                    tracker.sender_id, tracker.get_slot("USERNAME")
                )
            )
            profile_db.transact(
                from_account_number,
                to_account_number,
                amount_of_money,
            )

            dispatcher.utter_message(response="utter_transfer_complete")

            amount_transferred = float(tracker.get_slot("amount_transferred"))
            slots["amount_transferred"] = amount_transferred + amount_of_money
        else:
            dispatcher.utter_message(response="utter_transfer_cancelled")

        return [SlotSet(slot, value) for slot, value in slots.items()]


class ValidateTransferMoneyForm(CustomFormValidationAction):
    """Validates Slots of the transfer_money_form"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "validate_transfer_money_form"

    async def validate_USERNAME(
        self,
        value: Text,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> Dict[Text, Any]:
        """Validates value of 'USERNAME' slot"""
        # It is possible that both Spacy & DIET extracted the USERNAME
        # Just pick the first one
        if isinstance(value, list):
            value = value[0]

        name = value.lower() if value else None
        known_recipients = profile_db.list_known_recipients(tracker.sender_id)
        first_names = [name.split()[0] for name in known_recipients]
        if name is not None and name in known_recipients:
            return {"USERNAME": name.title()}

        if name in first_names:
            index = first_names.index(name)
            fullname = known_recipients[index]
            return {"USERNAME": fullname.title()}

        dispatcher.utter_message(response="utter_unknown_recipient", USERNAME=value)
        return {"USERNAME": None}

    async def explain_USERNAME(
        self,
        value: Text,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> Dict[Text, Any]:
        """Explains 'USERNAME' slot"""
        recipients = profile_db.list_known_recipients(tracker.sender_id)
        formatted_recipients = "\n" + "\n".join(
            [f"- {recipient.title()}" for recipient in recipients]
        )
        dispatcher.utter_message(
            response="utter_recipients",
            formatted_recipients=formatted_recipients,
        )
        return {}

    async def validate_amount_of_money(
        self,
        value: Text,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> Dict[Text, Any]:
        """Validates value of 'amount-of-money' slot"""
        account_balance = profile_db.get_account_balance(tracker.sender_id)
        try:
            entity = get_entity_details(
                tracker, "amount-of-money"
            ) or get_entity_details(tracker, "number")
            amount_currency = parse_duckling_currency(entity)
            if not amount_currency:
                raise TypeError
            if account_balance < float(amount_currency.get("amount-of-money")):
                dispatcher.utter_message(response="utter_insufficient_funds")
                return {"amount-of-money": None}
            return amount_currency
        except (TypeError, AttributeError):
            dispatcher.utter_message(response="utter_no_payment_amount")
            return {"amount-of-money": None}

    async def validate_zz_confirm_form(
        self,
        value: Text,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> Dict[Text, Any]:
        """Validates value of 'zz_confirm_form' slot"""
        if value in ["yes", "no"]:
            return {"zz_confirm_form": value}

        return {"zz_confirm_form": None}


class ActionShowBalance(Action):
    """Shows the balance of bank or credit card accounts"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_show_balance"

    async def run(
        self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        #print(json.dumps(tracker.latest_message.intent))
        """Executes the custom action"""
        account_type = tracker.get_slot("account_type")

        if account_type == "credit":
            # show credit card balance
            credit_card = tracker.get_slot("credit_card")
            available_cards = profile_db.list_credit_cards(tracker.sender_id)

            if credit_card and credit_card.lower() in available_cards:
                current_balance = profile_db.get_credit_card_balance(
                    tracker.sender_id, credit_card
                )
                dispatcher.utter_message(
                    response="utter_credit_card_balance",
                    **{
                        "credit_card": credit_card.title(),
                        "credit_card_balance": f"{current_balance:.2f}",
                    },
                )
            else:
                for credit_card in profile_db.list_credit_cards(tracker.sender_id):
                    current_balance = profile_db.get_credit_card_balance(
                        tracker.sender_id, credit_card
                    )
                    dispatcher.utter_message(
                        response="utter_credit_card_balance",
                        **{
                            "credit_card": credit_card.title(),
                            "credit_card_balance": f"{current_balance:.2f}",
                        },
                    )
        else:
            # show bank account balance
            account_balance = profile_db.get_account_balance(tracker.sender_id)
            amount = tracker.get_slot("amount_transferred")
            if amount:
                amount = float(tracker.get_slot("amount_transferred"))
                init_account_balance = account_balance + amount
                dispatcher.utter_message(
                    response="utter_changed_account_balance",
                    init_account_balance=f"{init_account_balance:.2f}",
                    account_balance=f"{account_balance:.2f}",
                )
            else:
                dispatcher.utter_message(
                    response="utter_account_balance",
                    init_account_balance=f"{account_balance:.2f}",
                )

        events = []
        active_form_name = tracker.active_form.get("name")
        if active_form_name:
            # keep the tracker clean for the predictions with form switch stories
            events.append(UserUtteranceReverted())
            # trigger utter_ask_{form}_AA_CONTINUE_FORM, by making it the requested_slot
            events.append(SlotSet("AA_CONTINUE_FORM", None))
            # avoid that bot goes in listen mode after UserUtteranceReverted
            events.append(FollowupAction(active_form_name))

        return events


class ActionShowRecipients(Action):
    """Lists the contents of then known_recipients slot"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_show_recipients"

    async def run(
        self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        print(tracker.latest_message['intent'].get('name'))
        """Executes the custom action"""
        recipients = profile_db.list_known_recipients(tracker.sender_id)
        formatted_recipients = "\n" + "\n".join(
            [f"- {recipient.title()}" for recipient in recipients]
        )
        dispatcher.utter_message(
            response="utter_recipients",
            formatted_recipients=formatted_recipients,
        )

        events = []
        active_form_name = tracker.active_form.get("name")
        if active_form_name:
            # keep the tracker clean for the predictions with form switch stories
            events.append(UserUtteranceReverted())
            # trigger utter_ask_{form}_AA_CONTINUE_FORM, by making it the requested_slot
            events.append(SlotSet("AA_CONTINUE_FORM", None))
            # # avoid that bot goes in listen mode after UserUtteranceReverted
            events.append(FollowupAction(active_form_name))

        return events


class ActionShowTransferCharge(Action):
    """Lists the transfer charges"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_show_transfer_charge"

    async def run(
        self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        print(tracker.latest_message['intent'].get('name'))
        """Executes the custom action"""
        dispatcher.utter_message(response="utter_transfer_charge")

        events = []
        active_form_name = tracker.active_form.get("name")
        if active_form_name:
            # keep the tracker clean for the predictions with form switch stories
            events.append(UserUtteranceReverted())
            # trigger utter_ask_{form}_AA_CONTINUE_FORM, by making it the requested_slot
            events.append(SlotSet("AA_CONTINUE_FORM", None))
            # # avoid that bot goes in listen mode after UserUtteranceReverted
            events.append(FollowupAction(active_form_name))

        return events


class ActionSessionStart(Action):
    """Executes at start of session"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_session_start"

    @staticmethod
    def _slot_set_events_from_tracker(
        tracker: "Tracker",
    ) -> List["SlotSet"]:
        """Fetches SlotSet events from tracker and carries over keys and values"""

        # when restarting most slots should be reset
        relevant_slots = ["currency"]

        return [
            SlotSet(
                key=event.get("name"),
                value=event.get("value"),
            )
            for event in tracker.events
            if event.get("event") == "slot" and event.get("name") in relevant_slots
        ]

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[EventType]:
        """Executes the custom action"""
        # the session should begin with a `session_started` event
        events = [SessionStarted()]

        events.extend(self._slot_set_events_from_tracker(tracker))

        # create a mock profile by populating database with values specific to tracker.sender_id
        profile_db.populate_profile_db(tracker.sender_id)
        currency = profile_db.get_currency(tracker.sender_id)

        #-----------------------------------------Session Id Exists or Not-------------------------------
        
        sv=tracker.current_slot_values()
        sv_json_object = json.dumps(sv, indent = 4)
        phone = tracker.get_slot("phone_number")
        print("session started and set everything Null to DB initially")
        account = db_manager.set_session_id(
                tracker.sender_id, phone, sv_json_object
            )
        print(account)
        
        #---------------------------------------------------------------------------------------------------------------

        # initialize slots from mock profile
        events.append(SlotSet("currency", currency))

        # add `action_listen` at the end
        events.append(ActionExecuted("action_listen"))

        return events


class ActionRestart(Action):
    """Executes after restart of a session"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_restart"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[EventType]:
        """Executes the custom action"""
        return [Restarted(), FollowupAction("action_session_start")]

class ActionSessionRestart(Action):
    """Executes after restart of a session"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_SessionRestart"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[EventType]:
        """Executes the custom action"""
        ActionExecuted("action_session_start")
        return []


class ActionAskTransactionSearchFormConfirm(Action):
    """Asks for the 'zz_confirm_form' slot of 'transaction_search_form'

    A custom action is used instead of an 'utter_ask' response because a different
    question is asked based on 'search_type' and 'vendor_name' slots.
    """

    def name(self) -> Text:
        return "action_ask_transaction_search_form_zz_confirm_form"

    async def run(
        self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        """Executes the custom action"""
        search_type = tracker.get_slot("search_type")
        vendor_name = tracker.get_slot("vendor_name")
        start_time_formatted = tracker.get_slot("start_time_formatted")
        end_time_formatted = tracker.get_slot("end_time_formatted")

        if vendor_name:
            vendor_name = f" with {vendor_name}"
        else:
            vendor_name = ""
        if search_type == "spend":
            text = (
                f"Do you want to search for transactions{vendor_name} between "
                f"{start_time_formatted} and {end_time_formatted}?"
            )
        elif search_type == "deposit":
            text = (
                f"Do you want to search deposits made to your account between "
                f"{start_time_formatted} and {end_time_formatted}?"
            )
        buttons = [
            {"payload": "/affirm", "title": "Yes"},
            {"payload": "/deny", "title": "No"},
        ]

        dispatcher.utter_message(text=text, buttons=buttons)

        return []


class ActionSwitchFormsAsk(Action):
    """Asks to switch forms"""

    def name(self) -> Text:
        return "action_switch_forms_ask"

    async def run(
        self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        """Executes the custom action"""
        active_form_name = tracker.active_form.get("name")
        intent_name = tracker.latest_message["intent"]["name"]
        next_form_name = NEXT_FORM_NAME.get(intent_name)

        if (
            active_form_name not in FORM_DESCRIPTION.keys()
            or next_form_name not in FORM_DESCRIPTION.keys()
        ):
            logger.debug(
                f"Cannot create text for `active_form_name={active_form_name}` & "
                f"`next_form_name={next_form_name}`"
            )
            next_form_name = None
        else:
            text = (
                f"We haven't completed the {FORM_DESCRIPTION[active_form_name]} yet. "
                f"Are you sure you want to switch to {FORM_DESCRIPTION[next_form_name]}?"
            )
            buttons = [
                {"payload": "/affirm", "title": "Yes"},
                {"payload": "/deny", "title": "No"},
            ]
            dispatcher.utter_message(text=text, buttons=buttons)
        return [SlotSet("next_form_name", next_form_name)]


class ActionSwitchFormsDeny(Action):
    """Does not switch forms"""

    def name(self) -> Text:
        return "action_switch_forms_deny"

    async def run(
        self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        """Executes the custom action"""
        active_form_name = tracker.active_form.get("name")

        if active_form_name not in FORM_DESCRIPTION.keys():
            logger.debug(
                f"Cannot create text for `active_form_name={active_form_name}`."
            )
        else:
            text = f"Ok, let's continue with the {FORM_DESCRIPTION[active_form_name]}."
            dispatcher.utter_message(text=text)

        return [SlotSet("next_form_name", None)]


class ActionSwitchFormsAffirm(Action):
    """Switches forms"""

    def name(self) -> Text:
        return "action_switch_forms_affirm"

    async def run(
        self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        """Executes the custom action"""
        active_form_name = tracker.active_form.get("name")
        next_form_name = tracker.get_slot("next_form_name")

        if (
            active_form_name not in FORM_DESCRIPTION.keys()
            or next_form_name not in FORM_DESCRIPTION.keys()
        ):
            logger.debug(
                f"Cannot create text for `active_form_name={active_form_name}` & "
                f"`next_form_name={next_form_name}`"
            )
        else:
            text = (
                f"Great. Let's switch from the {FORM_DESCRIPTION[active_form_name]} "
                f"to {FORM_DESCRIPTION[next_form_name]}. "
                f"Once completed, you will have the option to switch back."
            )
            dispatcher.utter_message(text=text)

        return [
            SlotSet("previous_form_name", active_form_name),
            SlotSet("next_form_name", None),
        ]


class ActionSwitchBackAsk(Action):
    """Asks to switch back to previous form"""

    def name(self) -> Text:
        return "action_switch_back_ask"

    async def run(
        self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        """Executes the custom action"""
        previous_form_name = tracker.get_slot("previous_form_name")

        if previous_form_name not in FORM_DESCRIPTION.keys():
            logger.debug(
                f"Cannot create text for `previous_form_name={previous_form_name}`"
            )
            previous_form_name = None
        else:
            text = (
                f"Would you like to go back to the "
                f"{FORM_DESCRIPTION[previous_form_name]} now?."
            )
            buttons = [
                {"payload": "/affirm", "title": "Yes"},
                {"payload": "/deny", "title": "No"},
            ]
            dispatcher.utter_message(text=text, buttons=buttons)

        return [SlotSet("previous_form_name", None)]

class ActionThanks(Action):
    """action_thanks"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_thanks"
    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Executes the action"""
        currentTime = datetime.datetime.now()
        currentTime.hour

        if 3<= currentTime.hour < 12:
           print('Good morning.')
           dispatcher.utter_message(response="utter_thanks")
           dispatcher.utter_message(response="utter_goodbye")
        elif 12 <= currentTime.hour < 16:
            print('Good afternoon.')
            dispatcher.utter_message(response="utter_thanks_afternoon")
            dispatcher.utter_message(response="utter_goodbye")
        elif 16 <= currentTime.hour < 19:
            print('Good evening.')
            dispatcher.utter_message(response="utter_thanks_evening")
            dispatcher.utter_message(response="utter_goodbye")
        elif 19 <= currentTime.hour < 3:
            print('Good night.')
            dispatcher.utter_message(response="utter_thanks_night")
            dispatcher.utter_message(response="utter_goodbye")
        else:
            print('Good unknown time.')
            dispatcher.utter_message(response="utter_goodbye")

        return []

class ActionFAQ(Action):
    """FAQ"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_FAQ"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        print(tracker.latest_message['intent'].get('name'))
        """Executes the action"""

        dispatcher.utter_message(text="For more information you can visit this [FAQ documents] (https://www.ucb.com.bd/reports/uclick/uclick-faq-final.pdf)")
        dispatcher.utter_message(text="For any types of Form you can visit [this site] too,(https://www.ucb.com.bd/news-and-events/downloads/).")
        dispatcher.utter_message(text="For More Visit this [Link] (https://www.ucb.com.bd/support/contact-us/)")

        return []

class ActionComplainHandeling(Action):
    """action_listen_complain_details"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_listen_complain_details"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        print(tracker.latest_message['intent'].get('name'))
        """Executes the action"""
        complain_details = tracker.latest_message['text']
        print("hello", complain_details)
        # dispatcher.utter_message(text="Your complain is - "+ complain_details)
        dispatcher.utter_message(response="utter_acknowledge_complain")
        dispatcher.utter_message(response="utter_tell_saved_complain")

        account = db_manager.set_slot_value(tracker.sender_id, "complain_details", complain_details)
        """api call would be here"""
        return [SlotSet("complain_details",complain_details)]

class ActionResetSlots(Action):
    """action_reset_all_slots"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_reset_all_slots"
    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Executes the action"""
        print ("slots are being reset")
        return [AllSlotsReset()]

class ActionResetcomplainSlots(Action):
    """action_reset_complain_slots"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_reset_complain_slots"
    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Executes the action"""
        print ("slots are being reset")
        #return [AllSlotsReset()]
        return [SlotSet("complain_details", None)]


class ActionProductInfo(Action):
    """Product_info"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_Product_Info"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        print(tracker.latest_message['intent'].get('name'))
        """Executes the action"""

        dispatcher.utter_message(text="You can see all of the product info  [click here] (https://www.ucb.com.bd/). From the mentioned link you can click on 'Products & Services' option.")

        return []

class validate_change_customer_address_form(FormValidationAction):
    """validate_change_customer_address_form"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "validate_change_customer_address_form"
        
    async def validate_account_number(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Executes the action"""
        print("validate_account_number")
        ac_num = tracker.get_slot("account_number")
        print("account Number inside function: ", ac_num)

        number = None
        #BANGLA Check Here
        if(not is_ascii(ac_num)):  #If Bangla then enter here
            print("Hello, Check Bangla")
            if ac_num.isnumeric():
                number = BnToEn(ac_num)
                ac_num = str(number)
                print("Number : ", number)
                print(ac_num)

                if len(ac_num)==13 and ac_num != None:
                    print("Account Number is correct.")
                    account = db_manager.set_slot_value(tracker.sender_id, "account_number", ac_num)
                    return {"account_number": ac_num}
                else:
                    print("Invalid Account Number")
                    dispatcher.utter_message(response="utter_invalidACNumber")
                    return {"account_number": None}
        else:
            if len(ac_num)==13 and ac_num != None:
                print("Account Number is correct.")
                account = db_manager.set_slot_value(tracker.sender_id, "account_number", ac_num)
                return {"account_number": ac_num}
            else:
                print("Invalid Account Number")
                dispatcher.utter_message(response="utter_invalidACNumber")
                return {"account_number": None}

    async def validate_mailling_address(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        address = tracker.get_slot("mailling_address")
        print("address is inside function: ", address)
        print("NEED to Work on this.")

        return []


class validate_change_customer_phonenumber_form(FormValidationAction):
    """validate_change_customer_phonenumber_form"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "validate_change_customer_phonenumber_form"
        
    async def validate_account_number(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Executes the action"""
        print("validate_account_number")
        ac_num = tracker.get_slot("account_number")
        print("account Number inside function: ", ac_num)

        number = None
        #BANGLA Check Here
        if(not is_ascii(ac_num)):  #If Bangla then enter here
            print("Hello, Check Bangla")
            if ac_num.isnumeric():
                number = BnToEn(ac_num)
                ac_num = str(number)
                print("Number : ", number)
                print(ac_num)

                if len(ac_num)==13 and ac_num != None:
                    print("Account Number is correct.")
                    account = db_manager.set_slot_value(tracker.sender_id, "account_number", ac_num)
                    return {"account_number": ac_num}
                else:
                    print("Invalid Account Number")
                    dispatcher.utter_message(response="utter_invalidACNumber")
                    return {"account_number": None}
        else:
            if len(ac_num)==13 and ac_num != None:
                print("Account Number is correct.")
                account = db_manager.set_slot_value(tracker.sender_id, "account_number", ac_num)
                return {"account_number": ac_num}
            else:
                print("Invalid Account Number")
                dispatcher.utter_message(response="utter_invalidACNumber")
                return {"account_number": None}

    async def validate_phone_number(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        phone = tracker.get_slot("phone_number")
        print("Mobile Number inside function: ", phone)

        number = None
        #BANGLA Check Here
        if(not is_ascii(phone)):  #If Bangla then enter here
            print("Hello, Check Bangla")
            if phone.isnumeric():
                number = BnToEn(phone)
                phone = str(number)
                print("Number : ", number)
                print(phone)
                # print("Formated Cell Number: ", tracker.slots["phone_number"])
                if(len(phone)!=11):
                    dispatcher.utter_message(response="utter_invalidPHONE")
                    return {"phone_number": None}
                else:
                    account = db_manager.set_slot_value(tracker.sender_id, 'phone_number', phone)
                    print("Phone number is ", phone)
                    return {"phone_number": phone}
        else:
            if(len(phone)!=11):
                dispatcher.utter_message(response="utter_invalidPHONE")
                return {"phone_number": None}
            else:
                account = db_manager.set_slot_value(tracker.sender_id, 'phone_number', phone)
                print("Phone number is ", phone)
                return {"phone_number": phone}

class validate_change_customer_name_form(FormValidationAction):
    """validate_change_customer_name_form"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "validate_change_customer_name_form"
        
    async def validate_account_number(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Executes the action"""
        print("validate_account_number")
        ac_num = tracker.get_slot("account_number")
        print("account Number inside function: ", ac_num)

        number = None
        #BANGLA Check Here
        if(not is_ascii(ac_num)):  #If Bangla then enter here
            print("Hello, Check Bangla")
            if ac_num.isnumeric():
                number = BnToEn(ac_num)
                ac_num = str(number)
                print("Number : ", number)
                print(ac_num)

                if len(ac_num)==13 and ac_num != None:
                    print("Account Number is correct.")
                    account = db_manager.set_slot_value(tracker.sender_id, "account_number", ac_num)
                    return {"account_number": ac_num}
                else:
                    print("Invalid Account Number")
                    dispatcher.utter_message(response="utter_invalidACNumber")
                    return {"account_number": None}
        else:
            if len(ac_num)==13 and ac_num != None:
                print("Account Number is correct.")
                account = db_manager.set_slot_value(tracker.sender_id, "account_number", ac_num)
                return {"account_number": ac_num}
            else:
                print("Invalid Account Number")
                dispatcher.utter_message(response="utter_invalidACNumber")
                return {"account_number": None}
    
    def validate_USERNAME(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:

        name = tracker.get_slot("USERNAME")
        print("Name is in validate form and it is ",name)

        if(isinstance(name, list)):
            Name = max(name, key=len)
        else:
            Name = name

        #USERNAME can't be a number
        for character in Name:
            if character.isdigit():
                dispatcher.utter_message(response="utter_invalidUNAME")
                return [SlotSet("USERNAME", None)]
            # else:
            #     account = db_manager.set_slot_value(tracker.sender_id, "USERNAME", Name)
            #     return {"USERNAME": Name}
        if Name!=None:
            if (len(Name) <= 4 or not nlp(Name)):
                dispatcher.utter_message(response="utter_invalidUNAME")
                return {"USERNAME": None}
            else:
                account = db_manager.set_slot_value(tracker.sender_id, "USERNAME", Name)
                return {"USERNAME": Name}
        else:
            dispatcher.utter_message(response="utter_invalidUNAME")
            return {"USERNAME": None}

class validate_bill_payment_form(FormValidationAction):
    """validate_bill_payment_form"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "validate_bill_payment_form"

    async def validate_utility_type(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        Ulist = ["wasa", "electricity", "dth", "telephone", "internet"]
        utlity = tracker.get_slot("utility_type")
        print("utility type inside function: ", utlity)

        if utlity.lower() in Ulist:
            account = db_manager.set_slot_value(tracker.sender_id, 'utility_type', utlity)
            print("Utility bill is ", utlity)
        else:
            dispatcher.utter_message(text="Wrong Input. Please choose a correct option.")
            return {"utility_type": None}
        
    async def validate_account_number(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Executes the action"""
        print("validate_account_number")
        ac_num = tracker.get_slot("account_number")
        print("account Number inside function: ", ac_num)

        number = None
        #BANGLA Check Here
        if(not is_ascii(ac_num)):  #If Bangla then enter here
            print("Hello, Check Bangla")
            if ac_num.isnumeric():
                number = BnToEn(ac_num)
                ac_num = str(number)
                print("Number : ", number)
                print(ac_num)

                if len(ac_num)==13 and ac_num != None:
                    print("Account Number is correct.")
                    account = db_manager.set_slot_value(tracker.sender_id, "account_number", ac_num)
                    return {"account_number": ac_num}
                else:
                    print("Invalid Account Number")
                    dispatcher.utter_message(response="utter_invalidACNumber")
                    return {"account_number": None}
        else:
            if len(ac_num)==13 and ac_num != None:
                print("Account Number is correct.")
                account = db_manager.set_slot_value(tracker.sender_id, "account_number", ac_num)
                return {"account_number": ac_num}
            else:
                print("Invalid Account Number")
                dispatcher.utter_message(response="utter_invalidACNumber")
                return {"account_number": None}

    async def validate_amount_of_money(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        
        amount = tracker.get_slot("amount-of-money")
        print("amount inside function: ", amount)

        account_balance = profile_db.get_account_balance(tracker.sender_id)
        try:
            number = None
            #BANGLA Check Here
            if(not is_ascii(amount)):  #If Bangla then enter here
                print("Hello, Check Bangla")
                if amount.isnumeric():
                    number = BnToEn(amount)
                    amount = str(number)
                    print("Number : ", number)
                    print(amount)
                    if(int(amount)<=0):
                        dispatcher.utter_message(response="utter_invalidAMOUNT")
                        # print("1")
                        return {"AmountMoney": None, "amount-of-money": None}
                    else:
                        # print("2")
                        account = db_manager.set_slot_value(tracker.sender_id, 'AmountMoney', amount)
                        account = db_manager.set_slot_value(tracker.sender_id, 'amount-of-money', amount)
                        return {"AmountMoney": amount, "amount-of-money": amount}
                else:
                    # print("3")
                    return[ SlotSet("AmountMoney", None),
                            SlotSet("amount-of-money", None),
                            ]
            else:
                # print("4")
                if(int(amount)<=0):
                    # print("5")
                    dispatcher.utter_message(response="utter_invalidAMOUNT")
                    return {"AmountMoney": None, "amount-of-money": None}
                else:
                    account = db_manager.set_slot_value(tracker.sender_id, 'AmountMoney', amount)
                    account = db_manager.set_slot_value(tracker.sender_id, 'amount-of-money', amount)
                    print("Amount is ", amount)
                    return {"AmountMoney": amount, "amount-of-money": amount}
        finally:
            # print("1000")
            entity = get_entity_details(
                tracker, "amount-of-money"
            ) or get_entity_details(tracker, "number")

            if account_balance < float(amount):
                dispatcher.utter_message(response="utter_insufficient_funds")
                return {"amount-of-money": None, "AmountMoney": None}

        return []

class ActionLostCard(Action):
    """LostCard"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_lost_card"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Executes the action"""

        dispatcher.utter_message(text="Sir/Madam, Please contact to the Card Division. Address is: \nBulus Center,\nPlot-CWS-(A)-1,\nRoad No - 34,\nGulshan Avenue, Dhaka-1212,\nPhone +88-02-55668070, +88-09610999999,\nFax +88-02-7162970,\nE-Mail cards@ucb.com.bd")
        dispatcher.utter_message(text = "you can also visit [this url] (https://www.ucb.com.bd/cards/terms-and-conditions/) for more details.")

        return []

class ActionLoanDetails(Action):
    """action_show_loan_details"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_show_loan_details"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        print(tracker.latest_message['intent'].get('name'))
        """Executes the action"""
        loan_type= tracker.get_slot("loan_type").lower()
        print(loan_type)
        if(loan_type == "personal"):
            account = db_manager.set_slot_value(tracker.sender_id, "loan_type", "personal")
            dispatcher.utter_message(text="Personal loan has interest rate of 8%")
        if(loan_type == "home"):
            account = db_manager.set_slot_value(tracker.sender_id, "loan_type", "home")
            dispatcher.utter_message(text="Home loan has interest rate of 6%")
        if(loan_type == "auto"):
            account = db_manager.set_slot_value(tracker.sender_id, "loan_type", "auto")
            dispatcher.utter_message(text="Car loan has interest rate of 5%")

        dispatcher.utter_message(text="For more Details you can visit [this](https://www.ucb.com.bd/banking/retail-banking/personal-loan) for Loans.")
        dispatcher.utter_message(text="For SME Banking loans, visit [this url](https://www.ucb.com.bd/banking/sme-banking/).")

        return [SlotSet("loan_type",None)]


class ResetOpenForm(Action):
    """action_reset_open_procedure_form"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_reset_open_procedure_form"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        print(tracker.latest_message['intent'].get('name'))
        """Executes the action"""
        print("Reset Slot Function Called.")
        return[ SlotSet("email_address", None),
                SlotSet("USERNAME", None),
                SlotSet("account_type", None),
                SlotSet("card_type" ,  None),
                ]
class ResetStopChequeForm(Action):
    """action_reset_stop_cheque_form"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_reset_stopCHEQUE"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        # print(tracker.latest_message['intent'].get('name'))
        """Executes the action"""
        print("Reset Slot Function Called.")
        return[ SlotSet("cheque_number", None),
                SlotSet("amount-of-money", None),
                ]

class ResetBenificiaryValue(Action):
    """action_reset_BenificiaryValue"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_reset_BenificiaryValue"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        print(tracker.latest_message['intent'].get('name'))
        """Executes the action"""
        print("Reset Slot Function Called.")
        return[ SlotSet("USERNAME", None),
                SlotSet("phone_number", None),
                SlotSet("account_number", None),
                SlotSet("bank_name", None),
                ]

class ResetbillpaymentForm(Action):
    """action_reset_bill_payment_form"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_reset_bill_payment_form"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Executes the action"""
        print("Reset Slot Function Called.")
        return[ SlotSet("utility_type", None),
                SlotSet("account_number", None),
                SlotSet("amount-of-money", None),
                ]

class ResetMobileRechargeForm(Action):
    """action_reset_Mobile_recharge_form"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_reset_mobile_recharge_form"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Executes the action"""
        # return[ SlotSet("phone_number", None),
        #         SlotSet("amount-of-money", None),
        #         ]
        return[SlotSet("amount-of-money", None)]
class GetMobileNumberFromDB(Action):
    """action_GetMobileNumberFromDB"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_GetMobileNumberFromDB"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Executes the action"""

        ack = db_manager.get_session_id(tracker.sender_id)
        print(ack)
        print("slots values are ", type(ack[2]))
        SlotsFromDB = json.loads(ack[2])
        print(type(SlotsFromDB))
        print(SlotsFromDB)
        phone = SlotsFromDB["phone_number"]
        ack = SlotsFromDB["account_number"]
        crdnum = SlotsFromDB["card_number"]
        print("phone number From DB is ", phone)

        # phone = tracker.get_slot("phone_number")

        if phone!=None:
            return [SlotSet("phone_number", phone)]
        else:
             return [SlotSet("phone_number", None)]

        return[]
class MobileRechargeForm(Action):
    """action_Mobile_recharge_form"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_mobile_recharge_form"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Executes the action"""
        #---------------------------------------------------------
        latest_action = tracker.latest_action_name
        print(f"latest action is {latest_action}")
        latest_loop = tracker.active_loop
        print(f"latest active loop is {latest_loop}")
        intent_name = tracker.latest_message["intent"]["name"]
        print(f"latest intent is {intent_name}")
        #-----------------------------------------------------------
        phone = tracker.get_slot("phone_number")

        if phone!=None:
            dispatcher.utter_message(response="utter_is_phone_number")
        else:
             dispatcher.utter_message(response="utter_is_phone_number_prepaid")

        return[]

#-------------------------------------------------------------------------------------------------------------------------------
class ActionSwitchFormsAsk(Action):
    """Asks to switch"""

    def name(self) -> Text:
        return "action_switch_ask"

    async def run(
        self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        """Executes the custom action"""
        # active_form_name = tracker.active_form.get("name")
        intent_name = tracker.latest_message["intent"]["name"]
        # next_form_name = NEXT_FORM_NAME.get(intent_name)

        # if (
        #     active_form_name not in FORM_DESCRIPTION.keys()
        #     or next_form_name not in FORM_DESCRIPTION.keys()
        # ):
        #     logger.debug(
        #         f"Cannot create text for `active_form_name={active_form_name}` & "
        #         f"`next_form_name={next_form_name}`"
        #     )
        #     next_form_name = None
        # else:
        text = (
            f"We haven't completed the current task yet. "
            f"Are you sure you want to switch to {intent_name}?"
        )
        buttons = [
            {"payload": "/affirm", "title": "Yes"},
            {"payload": "/deny", "title": "No"},
        ]
        dispatcher.utter_message(text=text, buttons=buttons)
        return []


class ActionSwitchDeny(Action):
    """Does not switch forms"""

    def name(self) -> Text:
        return "action_switch_deny"

    async def run(
        self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        """Executes the custom action"""
        phone = tracker.get_slot("phone_number")
        # text = f"Ok, let's continue with a New Mobile Number."
        if phone!=None:
            dispatcher.utter_message(response="utter_new_Num")
        else:
            dispatcher.utter_message(response="utter_Prepaid_Num")

        # return [SlotSet("next_form_name", None)]
        return[ SlotSet("phone_number", None),
                SlotSet("amount-of-money", None),
                ]


class ActionSwitchAffirm(Action):
    """Switches forms"""

    def name(self) -> Text:
        return "action_switch_affirm"

    async def run(
        self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        """Executes the custom action"""
        phone = tracker.get_slot("phone_number")
        if phone!=None:
            dispatcher.utter_message(response="utter_Yes_Phone_Num")
        else:
            dispatcher.utter_message(response="utter_Prepaid_Num")

        return[SlotSet("amount-of-money", None)]

class ActionPreviousValue(Action):
    """previous value"""

    def name(self) -> Text:
        return "Action_previous_Value"

    async def run(
        self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        """Executes the custom action"""
        previousAmount = tracker.get_slot("AmountMoney")
        print("previous value is ", previousAmount)
        
        #DATABASE VAlue
        ack = db_manager.get_session_id(tracker.sender_id)
        print(ack)
        print("slots values are ", type(ack[2]))
        SlotsFromDB = json.loads(ack[2])
        print(type(SlotsFromDB))
        print(SlotsFromDB)
        amt = SlotsFromDB["amount-of-money"]
        print("previous value From DB is ", amt)
        latest_action = tracker.latest_action_name
        current_state = Tracker.current_state
        print(f"latest action is {latest_action}")
        print(f"Current state is {current_state}")
        
        if previousAmount!=None:
            if int(previousAmount)>0:
                dispatcher.utter_message(response="utter_Yes_Previous_Value")
                return[SlotSet("amount-of-money", previousAmount)]
            else:
                dispatcher.utter_message(response="utter_No_Previous_Value")
                return[ SlotSet("AmountMoney", None),
                    SlotSet("amount-of-money", None),
                ]
        else:
            dispatcher.utter_message(response="utter_No_Previous_Value")
            return[ SlotSet("AmountMoney", None),
                SlotSet("amount-of-money", None),
                ]

        return[]

#-------------------------------------------------------------------------------------------------------------------------------
class validate_mobile_recharge_form(FormValidationAction):
    """validate_mobile_recharge_form"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "validate_mobile_recharge_form"

    async def validate_phone_number(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        phone = tracker.get_slot("phone_number")
        print("Mobile Number inside function: ", phone)

        #------------------------------------------------------------------
        latest_action = tracker.latest_action_name
        print(f"latest action is {latest_action}")
        latest_loop = tracker.active_loop
        print(f"latest active loop is {latest_loop}")
        intent_name = tracker.latest_message["intent"]["name"]
        print(f"latest intent is {intent_name}")
        #---------------------------------------------------------------------

        number = None
        #BANGLA Check Here
        if(not is_ascii(phone)):  #If Bangla then enter here
            print("Hello, Check Bangla")
            if phone.isnumeric():
                number = BnToEn(phone)
                phone = str(number)
                print("Number : ", number)
                print(phone)
                # print("Formated Cell Number: ", tracker.slots["phone_number"])
                if(len(phone)!=11):
                    dispatcher.utter_message(response="utter_invalidPHONE")
                    return {"phone_number": None}
                else:
                    account = db_manager.set_slot_value(tracker.sender_id, 'phone_number', phone)
                    print("Phone number is ", phone)
                    return {"phone_number": phone}
        else:
            if(len(phone)!=11):
                dispatcher.utter_message(response="utter_invalidPHONE")
                return {"phone_number": None}
            else:
                account = db_manager.set_slot_value(tracker.sender_id, 'phone_number', phone)
                print("Phone number is ", phone)
                return {"phone_number": phone}

    async def validate_amount_of_money(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        
        amount = tracker.get_slot("amount-of-money")
        print("amount inside function: ", amount)

        account_balance = profile_db.get_account_balance(tracker.sender_id)
        try:
            number = None
            #BANGLA Check Here
            if(not is_ascii(amount)):  #If Bangla then enter here
                print("Hello, Check Bangla")
                if amount.isnumeric():
                    number = BnToEn(amount)
                    amount = str(number)
                    print("Number : ", number)
                    print(amount)
                    if(int(amount)<=0):
                        dispatcher.utter_message(response="utter_invalidAMOUNT")
                        # print("1")
                        return {"AmountMoney": None, "amount-of-money": None}
                    else:
                        # print("2")
                        account = db_manager.set_slot_value(tracker.sender_id, 'AmountMoney', amount)
                        account = db_manager.set_slot_value(tracker.sender_id, 'amount-of-money', amount)
                        return {"AmountMoney": amount, "amount-of-money": amount}
                else:
                    # print("3")
                    return[ SlotSet("AmountMoney", None),
                            SlotSet("amount-of-money", None),
                            ]
            else:
                # print("4")
                if(int(amount)<=0):
                    # print("5")
                    dispatcher.utter_message(response="utter_invalidAMOUNT")
                    return {"AmountMoney": None, "amount-of-money": None}
                else:
                    account = db_manager.set_slot_value(tracker.sender_id, 'AmountMoney', amount)
                    account = db_manager.set_slot_value(tracker.sender_id, 'amount-of-money', amount)
                    print("Amount is ", amount)
                    return {"AmountMoney": amount, "amount-of-money": amount}
        finally:
            # print("1000")
            entity = get_entity_details(
                tracker, "amount-of-money"
            ) or get_entity_details(tracker, "number")

            if account_balance < float(amount):
                dispatcher.utter_message(response="utter_insufficient_funds")
                return {"amount-of-money": None, "AmountMoney": None}

        return []

class ResetcardBillForm(Action):
    """action_reset_card_bill_form"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_reset_card_bill_form"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        print(tracker.latest_message['intent'].get('name'))
        """Executes the action"""
        print("Reset Slot Function Called.")
        return[ SlotSet("card_number", None),
                SlotSet("Valid_DATE", None),
                SlotSet("CCV", None),
                SlotSet("amount-of-money", None),
                ]
class AffirmCardNumber(Action):
    """action_AffirmCardNumber"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_AffirmCardNumber"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Executes the action"""
        print("affirm to card Number")
        card = tracker.get_slot("card_number")
        if card!=None:
            dispatcher.utter_message(response="utter_card_number_affirm")
        else:
            dispatcher.utter_message(response="utter_card_credit")
        return []
class denyCardNumber(Action):
    """action_DenyCardNumber"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_DenyCardNumber"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Executes the action"""
        print("Deny to card Number")
        dispatcher.utter_message(response="utter_card_credit")
        return [SlotSet("card_number", None)]

class GetCardNumberFromDB(Action):
    """action_GetCradNumberFromDB"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_GetCardNumberFromDB"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Executes the action"""

        ack = db_manager.get_session_id(tracker.sender_id)
        print(ack)
        print("slots values are ", type(ack[2]))
        SlotsFromDB = json.loads(ack[2])
        print(type(SlotsFromDB))
        print(SlotsFromDB)
        crdnum = SlotsFromDB["card_number"]
        print("card number From DB is ", crdnum)

        if crdnum!=None:
            return [SlotSet("card_number", crdnum)]
        else:
             return [SlotSet("card_number", None)]

        return[]
class CardBillForm(Action):
    """action_card_bill_form"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_card_bill_form"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Executes the action"""

        card = tracker.get_slot("card_number")

        if card!=None:
            dispatcher.utter_message(response="utter_this_card")
        else:
             dispatcher.utter_message(response="utter_is_card_credit")

        return[]

class ActionCardBill(FormValidationAction):
    """validate_card_bill_form"""
    prev_ccv=''

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "validate_card_bill_form"

    async def validate_card_number(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Executes the action"""
        print("validate_card_number")
        card = tracker.get_slot("card_number")
        print("card Number is : ", card)

        #BANGLA Check Here
        if (not is_ascii(card)):  #If Bangla then enter here. is_ascii(otp) True for English
            cn = None
            if card.isnumeric():
                cn = BnToEn(card)
                print(str(cn))
                card = str(cn)
                print("card Number is ", card)
                tracker.slots["card_number"] = card
                if len(card)!=16 or card == None:
                    dispatcher.utter_message(response="utter_invalidCARDnumber")
                    return {"card_number": None}
                else:
                    print("Correct card Number")
                    account = db_manager.set_slot_value(tracker.sender_id, "card_number", card)
                    return {"card_number": card}
        else:
            if len(card)!=16 or card == None:
                dispatcher.utter_message(response="utter_invalidCARDnumber")
                return {"card_number": None}
            else:
                print("Correct card Number")
                account = db_manager.set_slot_value(tracker.sender_id, "card_number", card)
                return {"card_number": card}
    
    async def validate_Valid_DATE(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Executes the action"""
        print("validate_Expiry_DATE")
        card_date = tracker.get_slot("Valid_DATE")
        print("card expiry date is : ", card_date)
        currentyear = datetime.datetime.now().year
        currentmonth = datetime.datetime.now().month
        print(currentmonth)
        print(f"this is {currentyear}, and we are not getting smart.")
        currentyear = str(currentyear)
        currentyear = currentyear[-2:]
        currentyear = int(currentyear)
        print(currentyear)
        #BANGLA Check Here
        # if (not is_ascii(card_date)):  #If Bangla then enter here. is_ascii(otp) True for English
        #     cn = None
        #     if card.isnumeric():
        #         cn = BnToEn(card)
        #         print(str(cn))
        #         card = str(cn)
        #         print("card Number is ", card)
        #         tracker.slots["card_number"] = card
        #     return {"card_number": card}
        
        if len(card_date)!=5 or card_date == None:
            dispatcher.utter_message(response="utter_invalidValid_DATE")
            return {"Valid_DATE": None}
        else:
            expiry_date = str(card_date)
            print("first 2 digits: ", expiry_date[0:2])
            month = int(expiry_date[0:2])
            print("last 2 digit: ", expiry_date[-2:])
            year = int(expiry_date[-2:])
            
            if currentyear == year:
                if month >= currentmonth:
                    print("Expiry date is correct.")
                    account = db_manager.set_slot_value(tracker.sender_id, "Valid_DATE", card_date)
                    return {"Valid_DATE": card_date}
                else:
                    dispatcher.utter_message(response="utter_invalidValid_DATE")
                    return {"Valid_DATE": None}
            elif year > currentyear:
                if month> 0 and month<=12:
                    print("Expiry date is correct.")
                    account = db_manager.set_slot_value(tracker.sender_id, "Valid_DATE", card_date)
                    return {"Valid_DATE": card_date}
                else:
                    dispatcher.utter_message(response="utter_invalidValid_DATE")
                    return {"Valid_DATE": None}
            else:
                dispatcher.utter_message(response="utter_invalidValid_DATE")
                return {"Valid_DATE": None}


    async def validate_CCV(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Executes the action"""

        ack = db_manager.get_session_id(tracker.sender_id)
        print(ack)
        print("slots values are ", type(ack[2]))
        SlotsFromDB = json.loads(ack[2])
        print(type(SlotsFromDB))
        print(SlotsFromDB)
        cvv = SlotsFromDB["CCV"]
        print(f"CVV form DB is {cvv}")

        # if cvv != None:
        #     return [SlotSet("amount-of-money": amount_money)]

        ccv = tracker.get_slot("CCV")

        text  = ''
        for event in tracker.events:
            if (event.get("event") == "bot") and (event.get("event") is not None):
                text = event.get("text")
        print(f"Bot last message : {text}")
        print("----------------------------------------------------------------")

        for e in reversed(tracker.events):
            if e.get("event") == 'bot':
                utter_action = e.get('metadata', {}).get('utter_action')
                logger.debug(f"utter_action: {utter_action}")
                print(f"utter_action: {utter_action}")
                print(f"type of utter_action is {type(utter_action)}")
                if utter_action == "utter_ask_amount-of-money":
                    print(f"action name is {utter_action}, and now inside the if condition")
                    return {"amount-of-money": ccv, "CCV": cvv} + ActionExecuted("validate_amount_of_money")
                break

        amount_money=''
        print("validate_CCV")

        print("card ccv is : ", ccv)
        if(len(self.prev_ccv)>0):
            amount_money=ccv
            ccv=self.prev_ccv
            self.prev_ccv=''
            return {"CCV": ccv,"amount-of-money": amount_money}
        else:
            self.prev_ccv=ccv
        
        
        #BANGLA Check Here
        if (not is_ascii(ccv)):  #If Bangla then enter here. is_ascii(otp) True for English
            cn = None
            if ccv.isnumeric():
                cn = BnToEn(ccv)
                print(str(cn))
                ccv = str(cn)
                print("CCV Number is ", ccv)
                tracker.slots["CCV"] = ccv
                if len(ccv)!=3 or ccv == None:
                    dispatcher.utter_message(response="utter_invalidCCV")
                    return {"CCV": None}
                else:
                    print("Correct CCV Number")
                    account = db_manager.set_slot_value(tracker.sender_id, "CCV", ccv)
                    return {"CCV": ccv}
        else:
            if len(ccv)!=3 or ccv == None:
                dispatcher.utter_message(response="utter_invalidCCV")
                return {"CCV": None}
            else:
                print("Correct CCV Number")
                account = db_manager.set_slot_value(tracker.sender_id, "CCV", ccv)
                return {"CCV": ccv}
    async def validate_amount_of_money(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        print("CCV in amount validation:", tracker.get_slot("CCV"))
        amount = tracker.get_slot("amount-of-money")
        print("amount inside function: ", amount)

        account_balance = profile_db.get_account_balance(tracker.sender_id)

        number = None
        #BANGLA Check Here
        if(not is_ascii(amount)):  #If Bangla then enter here
            print("Hello, Check Bangla")
            if amount.isnumeric():
                number = BnToEn(amount)
                amount = str(number)
                print("Number : ", number)
                print(amount)
                if(int(amount)<=0):
                    dispatcher.utter_message(response="utter_invalidAMOUNT")
                    # print("1")
                    return {"AmountMoney": None, "amount-of-money": None}
                else:
                    # print("2")
                    account = db_manager.set_slot_value(tracker.sender_id, 'AmountMoney', amount)
                    account = db_manager.set_slot_value(tracker.sender_id, 'amount-of-money', amount)
                    return {"AmountMoney": amount, "amount-of-money": amount}
            else:
                # print("3")
                return[ SlotSet("AmountMoney", None),
                        SlotSet("amount-of-money", None),
                        ]
        else:
            # print("4")
            if(int(amount)<=0):
                # print("5")
                dispatcher.utter_message(response="utter_invalidAMOUNT")
                return {"AmountMoney": None, "amount-of-money": None}
            else:
                account = db_manager.set_slot_value(tracker.sender_id, 'AmountMoney', amount)
                account = db_manager.set_slot_value(tracker.sender_id, 'amount-of-money', amount)
                print("Amount is ", amount)
                return {"AmountMoney": amount, "amount-of-money": amount}

        return []


class ResetComplainDetails(Action):
    """action_reset_complain_details_form"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_reset_complain_details_form"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Executes the action"""
        print("Reset Slot Function Called.")
        return[ SlotSet("complain_details", None),
                ]

class ResetCustomerNameChange(Action):
    """action_reset_customer_name_form"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_reset_customer_name_form"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        print(tracker.latest_message['intent'].get('name'))
        """Executes the action"""
        print("Reset Slot Function Called.")
        return[ SlotSet("account_number", None),
                SlotSet("USERNAME", None),
                ]

class ResetCustomerPhoneNumberChange(Action):
    """action_reset_customer_phonenumber_form"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_reset_customer_Phonenumber_form"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        print(tracker.latest_message['intent'].get('name'))
        """Executes the action"""
        print("Reset Slot Function Called.")
        return[ SlotSet("account_number", None),
                SlotSet("phone_number", None),
                ]

class ResetCustomerAddressChange(Action):
    """action_reset_customer_address_form"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_reset_customer_address_form"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Executes the action"""
        print("Reset Slot Function Called.")
        return[ SlotSet("account_number", None),
                SlotSet("mailling_address", None),
                ]


class ActionOfferHandeling(Action):
    """action_offer_details"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_offer_details"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Executes the action"""

        offerType = tracker.get_slot("offer_type")
        print("action_offer_details Function Called.",offerType)

        # if offerType != None:
        #     offerType = offerType.lower()

        if offerType == "Upay": 
            account = db_manager.set_slot_value(tracker.sender_id, 'offer_type', "Upay")
            dispatcher.utter_message(text = "Visit [Latest Offer] (https://www.upaybd.com/Latest-offer) Page for detail about upay.")
        elif offerType == "New":
            account = db_manager.set_slot_value(tracker.sender_id, 'offer_type', "New")
            dispatcher.utter_message(text = "Visit [Existing New Offer] (https://www.ucb.com.bd/banking/retail-banking/existing-new-offers) for details.")
        elif offerType == "Card":
            account = db_manager.set_slot_value(tracker.sender_id, 'offer_type', "Card")
            dispatcher.utter_message(text = "Visit [Card Offer] (https://www.ucb.com.bd/cards/card-features) for details about cards")
        else:
            dispatcher.utter_message(text = "Visit [UCB] (https://www.ucb.com.bd/) for detail offers.")

        return [SlotSet("offer_type", None),]

class ActionInterestRate(Action):
    """action_interest_rate_information"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_interest_rate_information"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        print(tracker.latest_message['intent'].get('name'))
        """Executes the action"""
        rate_type = tracker.get_slot("rate_type")
        # print("action_interest_rate_information Function Called.",rate_type)

        if rate_type.lower() == "current":
            account = db_manager.set_slot_value(tracker.sender_id, 'rate_type', "current")
            dispatcher.utter_message(text = "current account interest rate 5%")
            #return {"rate_type": None}
        elif rate_type.lower() == "saving":
            account = db_manager.set_slot_value(tracker.sender_id, 'rate_type', "saving")
            dispatcher.utter_message(text = "saving account interest rate 10%")
            #return {"rate_type": None}
        elif rate_type.lower() == "emi":
            account = db_manager.set_slot_value(tracker.sender_id, 'rate_type', "emi")
            dispatcher.utter_message(text = "emi account interest rate 12%")
            #return {"rate_type": None}
        elif rate_type.lower() == "loan":
            account = db_manager.set_slot_value(tracker.sender_id, 'rate_type', "loan")
            dispatcher.utter_message(response = "utter_show_loan_type")
            #return {"rate_type": None}
        else:
            dispatcher.utter_message(text= "We do not have any interest you have asked for.")

        return[SlotSet("rate_type", None),]
        
class ChangeAddress(Action):
    """action_change_address"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_change_address"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        print(tracker.latest_message['intent'].get('name'))
        """Executes the action"""

        address = tracker.get_slot("mailling_address")
        print("Mailling Address is ", address)

        #check for multiple value as a list
        if(isinstance(address, list)):
            residence = ','.join(address)
            print(residence)
            account = db_manager.set_slot_value(tracker.sender_id, 'mailling_address', "residence")
            return [SlotSet("mailling_address", residence)]
        else:
            residence = address
            account = db_manager.set_slot_value(tracker.sender_id, 'mailling_address', "residence")
            return [SlotSet("mailling_address", residence)]

class ChangeName(Action):
    """action_change_name"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_change_name"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        print(tracker.latest_message['intent'].get('name'))
        """Executes the action"""

        name = tracker.get_slot("USERNAME")
        print("Name is in validate form and it is ",name)
        #check for multiple value as a list
        if(isinstance(name, list)):
            Name = max(name, key=len)
        else:
            Name = name

        if (len(Name) <= 4 or not nlp(Name)):
            dispatcher.utter_message(response="utter_invalidUNAME")
            return [SlotSet("USERNAME", None)]
        else:
            account = db_manager.set_slot_value(tracker.sender_id, "USERNAME", Name)
            return [SlotSet("USERNAME", Name)]




regex = '\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+.[a-zA-Z]{2,}\b'

# doc = nlp(u'আমি বাংলায় গান গাই। তুমি কি গাও?')

username = None
AccountList = ["fdr", "casa", "saving","loan","current"]

class ValidateOpenProcedureForm(FormValidationAction):
    """account open procedure validation"""
    

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "validate_open_procedure_form"

    def validate_email_address(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        email = tracker.get_slot("email_address")
        print("Email Validation Started....")
        print(email)
        if not (re.search(regex, email)):
            account = db_manager.set_slot_value(tracker.sender_id, 'email_address', email)
            print("Email set to DB:", account)
            return {"email_address": email}
        else:
            dispatcher.utter_message(response="utter_invalidEMAIL")
            return {"email_address": None}


    def validate_USERNAME(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:

        global username
        global AccountList
        name = tracker.get_slot("USERNAME")
        print("Name is in validate form and it is ",name)

        #BANGLA Check Here
        # if(not is_ascii(name)):  #If Bangla then enter here
        #     dispatcher.utter_message(response="utter_ENGLISH")
        #     return {"USERNAME": None}

        #check for multiple value as a list
        if(isinstance(name, list)):
            Name = max(name, key=len)
        else:
            Name = name

        #USERNAME can't be a number
        for character in Name:
            if character.isdigit():
                dispatcher.utter_message(response="utter_invalidUNAME")
                return [SlotSet("USERNAME", None)]
            # else:
            #     account = db_manager.set_slot_value(tracker.sender_id, "USERNAME", Name)
            #     SlotSet("USERNAME", Name)

        if(Name!=None):
            if (len(Name) <= 4 or not nlp(Name)):
                #username=None
                dispatcher.utter_message(response="utter_invalidUNAME")
                return {"USERNAME": None}
            else:
                account = db_manager.set_slot_value(tracker.sender_id, "USERNAME", Name)
                return {"USERNAME": Name}
        elif(Name in AccountList and username!=None):
            account = db_manager.set_slot_value(tracker.sender_id, "USERNAME", username)
            return {"USERNAME": username}
        else:
            username = Name
            account = db_manager.set_slot_value(tracker.sender_id, "USERNAME", Name)
            return {"USERNAME": Name}
        
    async def validate_phone_number(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        phone = tracker.get_slot("phone_number")
        print("Mobile Number inside function: ", phone)

        number = None
        #BANGLA Check Here
        if(not is_ascii(phone)):  #If Bangla then enter here
            print("Hello, Check Bangla")
            if phone.isnumeric():
                number = BnToEn(phone)
                phone = str(number)
                print("Number : ", number)
                print(phone)
                # print("Formated Cell Number: ", tracker.slots["phone_number"])
                if(len(phone)!=11):
                    dispatcher.utter_message(response="utter_invalidPHONE")
                    return {"phone_number": None}
                else:
                    print("Phone number is ", phone)
                    account = db_manager.set_slot_value(tracker.sender_id, "phone_number", phone)
                    return {"phone_number": phone}
        else:
            if(len(phone)!=11):
                dispatcher.utter_message(response="utter_invalidPHONE")
                return {"phone_number": None}
            else:
                print("Phone number is ", phone)
                account = db_manager.set_slot_value(tracker.sender_id, "phone_number", phone)
                return {"phone_number": phone}


    def validate_account_type(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        ac_type = tracker.get_slot("account_type").lower()
        if(username!=tracker.get_slot("USERNAME")):
            SlotSet("USERNAME", username)
        # AccountList = ["fdr", "casa", "saving","loan","current"]
        global AccountList
        print("account type in validate form is ", ac_type)

        if (ac_type not in AccountList):
            dispatcher.utter_message(text="Please Check the Account Type...")
            return {"account_type": None}
        else:
            account = db_manager.set_slot_value(tracker.sender_id, "account_type", ac_type.upper())
            return {"account_type": ac_type.upper()}

    def validate_card_type(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        CardList = ["visa platinum", "master", "visa", "credit", "amex", "atm", "debit"]
        card_type = tracker.get_slot("card_type").lower()

        print("inside validate form card type")
        print(card_type)

        if (card_type not in CardList):
            dispatcher.utter_message(response="utter_invalidCard")
            return {"card_type": None}
        else:
            account = db_manager.set_slot_value(tracker.sender_id, "card_type", card_type.upper())
            return {"card_type": card_type.upper()}

class ActionbkashBenificiary(FormValidationAction):
    """validate_Benificiary_form"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "validate_bKash_form"
    def validate_USERNAME(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:

        name = tracker.get_slot("USERNAME")
        print("Name is in validate form and it is ",name)

        #BANGLA Check Here
        # if(not is_ascii(name)):  #If Bangla then enter here
        #     dispatcher.utter_message(response="utter_ENGLISH")
        #     return {"USERNAME": None}

        #check for multiple value as a list
        if(isinstance(name, list)):
            Name = max(name, key=len)
        else:
            Name = name

        #USERNAME can't be a number
        for character in Name:
            if character.isdigit():
                dispatcher.utter_message(response="utter_invalidUNAME")
                return [SlotSet("USERNAME", None)]
            # else:
            #     account = db_manager.set_slot_value(tracker.sender_id, "USERNAME", Name)
            #     return {"USERNAME": Name}
        if Name!=None:
            if (len(Name) <= 4 or not nlp(Name)):
                dispatcher.utter_message(response="utter_invalidUNAME")
                return {"USERNAME": None}
            else:
                account = db_manager.set_slot_value(tracker.sender_id, "USERNAME", Name)
                return {"USERNAME": Name}
        else:
            dispatcher.utter_message(response="utter_invalidUNAME")
            return {"USERNAME": None}

    async def validate_phone_number(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        phone = tracker.get_slot("phone_number")
        print("Mobile Number inside function: ", phone)

        number = None
        #BANGLA Check Here
        if(not is_ascii(phone)):  #If Bangla then enter here
            print("Hello, Check Bangla")
            if phone.isnumeric():
                number = BnToEn(phone)
                phone = str(number)
                print("Number : ", number)
                print(phone)
                # print("Formated Cell Number: ", tracker.slots["phone_number"])
                if(len(phone)!=11):
                    dispatcher.utter_message(response="utter_invalidPHONE")
                    return {"phone_number": None}
                else:
                    print("Phone number is ", phone)
                    account = db_manager.set_slot_value(tracker.sender_id, "phone_number", phone)
                    return {"phone_number": phone}
        else:
            if(len(phone)!=11):
                dispatcher.utter_message(response="utter_invalidPHONE")
                return {"phone_number": None}
            else:
                print("Phone number is ", phone)
                account = db_manager.set_slot_value(tracker.sender_id, "phone_number", phone)
                return {"phone_number": phone}

class ActionBenificiary(FormValidationAction):
    """validate_Benificiary_form"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "validate_Bank_To_Bank_transfer_form"
    
    def validate_USERNAME(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:

        name = tracker.get_slot("USERNAME")
        print("Name is in validate form and it is ",name)

        #BANGLA Check Here
        # if(not is_ascii(name)):  #If Bangla then enter here
        #     dispatcher.utter_message(response="utter_ENGLISH")
        #     return {"USERNAME": None}

        #check for multiple value as a list
        if(isinstance(name, list)):
            Name = max(name, key=len)
        else:
            Name = name

        #USERNAME can't be a number
        for character in Name:
            if character.isdigit():
                dispatcher.utter_message(response="utter_invalidUNAME")
                return [SlotSet("USERNAME", None)]
            # else:
            #     account = db_manager.set_slot_value(tracker.sender_id, "USERNAME", Name)
            #     return {"USERNAME": Name}
        if Name!=None:
            if (len(Name) <= 4 or not nlp(Name)):
                dispatcher.utter_message(response="utter_invalidUNAME")
                return {"USERNAME": None}
            else:
                account = db_manager.set_slot_value(tracker.sender_id, "USERNAME", Name)
                return {"USERNAME": Name}
        else:
            dispatcher.utter_message(response="utter_invalidUNAME")
            return {"USERNAME": None}
    
    async def validate_bank_name(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Executes the action"""

        Bank_Name = tracker.get_slot("bank_name")
        print("Bank Name is : ", Bank_Name)

        #BANGLA Check Here
        if(not is_ascii(Bank_Name)):  #If Bangla then enter here
            dispatcher.utter_message(response="utter_ENGLISH")
            return {"bank_name": None}

        Bank_Name_List = ["BRAC Bank", "HSBC", "Sonali Bank", "City Bank", "United Commercial Bank", "Standard Chartered", "EBL"]

        temp = (map(lambda x: x.lower(), Bank_Name_List))
        BankNameList = list(temp)
        print(BankNameList)

        if (Bank_Name.lower() not in BankNameList):
            dispatcher.utter_message(response="utter_invalidBankName")
            return {"bank_name": None}
        else:
            print("Bank Name is Correct.")
            account = db_manager.set_slot_value(tracker.sender_id, "bank_name", Bank_Name.upper())
            return {"bank_name": Bank_Name.upper()}

    async def validate_account_number(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Executes the action"""
        print("validate_account_number")
        ac_num = tracker.get_slot("account_number")
        print("account Number inside function: ", ac_num)

        number = None
        #BANGLA Check Here
        if(not is_ascii(ac_num)):  #If Bangla then enter here
            print("Hello, Check Bangla")
            if ac_num.isnumeric():
                number = BnToEn(ac_num)
                ac_num = str(number)
                print("Number : ", number)
                print(ac_num)
            return {"account_number": ac_num}

        if len(ac_num)==13 and ac_num != None:
            print("Account Number is correct.")
            account = db_manager.set_slot_value(tracker.sender_id, "account_number", ac_num)
            return {"account_number": ac_num}
        else:
            print("Invalid Account Number")
            dispatcher.utter_message(response="utter_invalidACNumber")
            return {"account_number": None}

class ActionCheque(FormValidationAction):
    """validate_cheque"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "validate_stop_cheque_form"

    async def validate_cheque_number(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Executes the action"""
        print("validate_Cheque_number")
        cheque = tracker.get_slot("cheque_number")
        print("Cheque Number is : ", cheque)

        #BANGLA Check Here
        if (not is_ascii(cheque)):  #If Bangla then enter here. is_ascii(otp) True for English
            cn = None
            if cheque.isnumeric():
                cn = BnToEn(cheque)
                print(str(cn))
                cheque = str(cn)
                print("Cheque Number is ", cheque)
                tracker.slots["cheque_number"] = cheque
            return {"cheque_number": cheque}
        
        if len(cheque)!=8 or cheque == None:
            dispatcher.utter_message(response="utter_invalidCHEQUEnumber")
            return {"cheque_number": None}
        else:
            print("Correct Cheque Number")
            account = db_manager.set_slot_value(tracker.sender_id, "cheque_number", cheque)
            return {"cheque_number": cheque}
        
    async def validate_amount_of_money(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        
        amount = tracker.get_slot("amount-of-money")
        print("amount inside function: ", amount)

        account_balance = profile_db.get_account_balance(tracker.sender_id)

        number = None
        #BANGLA Check Here
        if(not is_ascii(amount)):  #If Bangla then enter here
            print("Hello, Check Bangla")
            if amount.isnumeric():
                number = BnToEn(amount)
                amount = str(number)
                print("Number : ", number)
                print(amount)
                if(int(amount)<=0):
                    dispatcher.utter_message(response="utter_invalidAMOUNT")
                    # print("1")
                    return {"AmountMoney": None, "amount-of-money": None}
                else:
                    # print("2")
                    account = db_manager.set_slot_value(tracker.sender_id, 'AmountMoney', amount)
                    account = db_manager.set_slot_value(tracker.sender_id, 'amount-of-money', amount)
                    return {"AmountMoney": amount, "amount-of-money": amount}
            else:
                # print("3")
                return[ SlotSet("AmountMoney", None),
                        SlotSet("amount-of-money", None),
                        ]
        else:
            # print("4")
            if(int(amount)<=0):
                # print("5")
                dispatcher.utter_message(response="utter_invalidAMOUNT")
                return {"AmountMoney": None, "amount-of-money": None}
            else:
                account = db_manager.set_slot_value(tracker.sender_id, 'AmountMoney', amount)
                account = db_manager.set_slot_value(tracker.sender_id, 'amount-of-money', amount)
                print("Amount is ", amount)
                return {"AmountMoney": amount, "amount-of-money": amount}

        return []

class ActionSetSessionToDB(Action):
    """Action_Set_SessionToDB"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "Action_Set_SessionToDB"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Executes the action"""
        print("set to DB")
        sv=tracker.current_slot_values()
        sv_json_object = json.dumps(sv, indent = 4)
        phone = tracker.get_slot("phone_number")
        print("Phone to set to DB is ", phone)
        account = db_manager.set_session_id(
                tracker.sender_id, phone, sv_json_object
            )
        print(account)

        ack = db_manager.get_session_id(tracker.sender_id)
        print(ack)
        print("slots values are ", type(ack[2]))
        SlotsFromDB = json.loads(ack[2])
        print(type(SlotsFromDB))
        print(SlotsFromDB)
        print("OTP From DB is ", SlotsFromDB["OTP"])
        otp = SlotsFromDB["OTP"]

        if otp!=None:
            print("Retrive Data from DB Successfully.")
        else:
            print("Retrive Data from DB Unuccessful.")
        return []

x = None
user_list=[]
class ActionOTPValidation(FormValidationAction):
    """action_OTP_form"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "validate_OTP_form"

    async def validate_OTP(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Executes the action"""
        global flag
        global x
        print(flag)
        sender_id=tracker.sender_id


        if flag == True:
            p = tracker.get_slot("phone_number")
            o = tracker.get_slot("OTP")
            if p == None or p == '':
                p = "01712000001"
            if o == None or o == '':
                o = "123456"
            print(f"Validate OTP func -> Phone: {p}, OTP: {o}")
            return {"phone_number": p, "OTP": o}
        
        otp = tracker.get_slot("OTP")
        print("OTP is : ", otp)

        #BANGLA Check Here
        if (not is_ascii(otp)):  #If Bangla then enter here. is_ascii(otp) True for English
            integer = None
            if otp.isnumeric():
                integer = BnToEn(otp)
                print(str(integer))
                otp = str(integer)
                print("OTP is ", otp)
                tracker.slots["OTP"] = otp

        if otp!=None and len(otp)==6 and otp==str(x):
            flag = True
            # dispatcher.utter_message(response = "utter_OTP_Received")
            print("Correct OTP")
            global user_list
            user_list.append(sender_id)
            print(user_list)
            return {"OTP": otp}
        else:
            if flag == False:
                dispatcher.utter_message(response = "utter_invalidOTP")

            print("Incorrect OTP")
            flag = False
            return {"OTP": None}

    async def validate_phone_number(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        phone = tracker.get_slot("phone_number")
        print("Mobile Number inside function: ", phone)

        global x

        if flag == True:
            p = tracker.get_slot("phone_number")
            o = tracker.get_slot("OTP")
            if p == None or p == '':
                p = "01712000001"
            if o == None or o == '':
                o = "123456"
            
            print(f"Validate Phone func -> Phone: {p}, OTP: {o}")
            return {"phone_number": p, "OTP": o}

        
        #BANGLA Check Here
        if(not is_ascii(phone)):  #If Bangla then enter here
            print("Hello, Check Bangla")
            number = None
            if phone.isnumeric():
                number = BnToEn(phone)
                phone = str(number)
                print("Number : ", number)
                print(phone)

                if flag == False:
                    if len(phone)==11:
                        phone_cpy = phone
                        phone = '+88' + phone
                        print("Mobile Number : ", phone)
                        account_sid = 'ACfbd8b020f286523f1b6afe13557e00c1'
                        auth_token = '6eb71f8e1b76f3a148982d12255dc902'
                        client = Client(account_sid, auth_token)

                        x = random.randint(100000, 999999)
                        # x = 123456
                        print(x)

                        message = client.messages \
                            .create(
                                    body="Hi from Rasa, Your OTP is " + str(x),
                                    from_='+1 318 594 4435',
                                    to=phone
                                )
                        print(message.sid)

                        return {"phone_number": phone_cpy}
                    else: 
                        dispatcher.utter_message(response="utter_invalidPHONE")
                        return {"phone_number": None}
                else:
                    return {"phone_number": phone}
        else:
            print("English Input")
            if flag == False:
                if len(phone)==11:
                    phone_cpy = phone
                    phone = '+88' + phone
                    print("Mobile Number : ", phone)
                    account_sid = 'ACfbd8b020f286523f1b6afe13557e00c1'
                    auth_token = '6eb71f8e1b76f3a148982d12255dc902'
                    client = Client(account_sid, auth_token)

                    # x = random.randint(100000, 999999)
                    x = 123456
                    print(x)

                    message = client.messages \
                        .create(
                                body="Hi from Rasa, Your OTP is " + str(x),
                                from_='+1 318 594 4435',
                                to=phone
                            )
                    print(message.sid)
                    return {"phone_number": phone_cpy}
                else: 
                    dispatcher.utter_message(response="utter_invalidPHONE")
                    return {"phone_number": None}
            else:
                return {"phone_number": phone}


class Check_OTP(Action):
    """Check_OTP"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "Check_OTP"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Executes the action"""
        global user_list
        print(user_list)
        sender_id = tracker.sender_id
        print(sender_id)

        global flag

        if(sender_id not in user_list):
            flag=False
        
        if flag == True:
            print("OTP Received.")
            p = tracker.get_slot("phone_number")
            o = tracker.get_slot("OTP")
            if p == None or p == '':
                p = "01712000001"
            if o == None or o == '':
                o = "123456"

            user_list.append(sender_id)
            print(f"Check OTP form -> Phone: {p}, OTP: {o}")
            return [SlotSet("phone_number", p), 
                    SlotSet("OTP", o),
                    ]
            # return []

        else:
            dispatcher.utter_message(response="utter_enterPHONE")
            print("Flag False.")
            SlotSet("OTP", None)
            flag = False
        return []

class ActionAdvertisement(Action):
    """action_advertisement_reminder"""

    def name(self) -> Text:
        return "action_schedule_reminder"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict[Text, Any]]:

        print(tracker)
        user_id = tracker.current_state()['sender_id']
        # user_id = tracker.sender_id
        events = tracker.current_state()["events"]
        print(user_id)

        global GlobalList

        date = datetime.datetime.now() + datetime.timedelta(seconds=10)
        entities = tracker.latest_message.get("entities")

        # intent_name = tracker.latest_message['intent'].get('name')

        #GlobalList = ["utter_Advertisement_1", "utter_Advertisement_2"]

        # for _ in range(len(GlobalList)):
        # In the future, We won't show random advertisement, rather we will stored last few intents and based on the intents 
        # we will make sure that the bot showing the right campaign by searching the database.
        # i = random.randint(0, len(GlobalList)-1)

        myclient = pymongo.MongoClient("mongodb://localhost:27017/")
        mydb = myclient["rasa"]
        campaign = mydb["campaign"]
        conversations = mydb["conversations"]

        data={
            "sender_id": user_id,
            "events": events
        }

        temp = conversations.insert(data)
        print(temp)

        for x in conversations.find( { "sender_id": str(user_id) } ).limit(15):
            for e in x["events"]:
                if(e["event"]=='user'):
                    GlobalList.append(e["parse_data"]["intent"]["name"])
        
        print(GlobalList)
        count = 0

        for intent_name in GlobalList[-1:-6:-1]:    #sequence[start:stop:step] (https://stackoverflow.com/questions/646644/how-to-get-last-items-of-a-list-in-python)
            for x in campaign.find({},{ "keyword": 1, "campaign_details": 1, "url": 1 }):
                print(x)
                keyword = x["keyword"]
                if(keyword!=None and keyword in intent_name and count==0):
                    print("Found Something.")
                    dispatcher.utter_message(x["campaign_details"])
                    count = count+1
                    if (x["url"]!= None):
                        dispatcher.utter_message(text = "[click Here] "+x["url"]+" for Details.")
                    else:
                        dispatcher.utter_message(text = "Please visit [United Commercial Bank] website. (https://www.ucb.com.bd/)")

        # dispatcher.utter_message(response = GlobalList[i])
        # story_intent = "EXTERNAL_"+GlobalList[i]
        story_intent = "utter_Wakeup"

        # print(intent_name)

        reminder = ReminderScheduled(
            "action_inactive_advertisement",
            trigger_date_time=date,
            entities=entities,
            name="utter_Wakeup",
            kill_on_user_message=True,
        )

        # return [ActionExecuted("utter_Advertisement_1")] +[UserUttered("/utter_Advertisement_1" + "utter_Advertisement_1", {
            #     "intent": {"name": "utter_Advertisement_1", "confidence": 1.0},
            #     "entities": {}
            # })]

        # return [reminder]
        return []

class ActionInactive(Action):
    """action_inactive_advertisement"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "action_inactive_advertisement"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Executes the action"""
        dt = datetime.datetime.now() + datetime.timedelta(seconds=15)
        myclient = pymongo.MongoClient("mongodb://localhost:27017/")
        mydb = myclient["rasa"]
        campaign = mydb["campaign"]

        data = []
        keyword_value = []
        
        for x in campaign.find({},{ "keyword": 1, "campaign_details": 1, "url": 1 }):
            data.append(x)
            keyword_value.append(x["keyword"])
        print(data)
        # random_campaign = random.choice(keyword_value)
        rand_data = random.choice(data)
        random_campaign =rand_data["keyword"]

        print(f"Random Keyword: {random_campaign}")
        
        dispatcher.utter_message(rand_data["campaign_details"])
        if (rand_data["url"]!= None):
            dispatcher.utter_message(text = "[click Here] "+rand_data["url"]+" for Details.")
        else:
            dispatcher.utter_message(text = "Please visit [United Commercial Bank] (https://www.ucb.com.bd/)")

        dispatcher.utter_message(response = "utter_Wakeup")

        return [ReminderScheduled("action_inactive_advertisement", trigger_date_time=dt, kill_on_user_message=True)]
        

class CantDo(Action):
    """Action_CantDo"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "Action_CantDo"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Executes the action"""
        dispatcher.utter_message(response = "utter_cant_do_1")
        dispatcher.utter_message(response = "utter_cant_do_2")
        dispatcher.utter_message(response = "utter_tell_me")

        
        return []

class ActionExplain(Action):
    """Action_Explain"""

    def name(self) -> Text:
        """Unique identifier of the action"""
        return "Action_Explain"

    async def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Executes the action"""
        what_explain = tracker.get_slot("Explain")
        print("Asked to know why we need ", what_explain)

        if(what_explain!=None):
            if (what_explain.lower()=="email" or what_explain.lower() == "email address"):
                dispatcher.utter_message(response = "utter_explain_email_address")
            elif(what_explain.lower()=="name" or what_explain.lower() == "username"):
                dispatcher.utter_message(response = "utter_explain_USERNAME")
            elif(what_explain.lower()=="account type" or what_explain.lower() == "account_types" or what_explain.lower() == "account types"):
                dispatcher.utter_message(response = "utter_explain_account_type")
            elif(what_explain.lower()=="card types" or what_explain.lower() == "card_types" or what_explain.lower() == "card type"):
                dispatcher.utter_message(response = "utter_explain_card_type")
            else:
                dispatcher.utter_message(response = "utter_explain")
        else:
            dispatcher.utter_message(response = "utter_explain")

        return [SlotSet("Explain", None)]

# class ActionRasaDB(Action):
#     """action_RasaDB"""

#     def name(self) -> Text:
#         """Unique identifier of the action"""
#         return "action_RasaDB"

#     async def run(
#         self,
#         dispatcher: CollectingDispatcher,
#         tracker: Tracker,
#         domain: Dict[Text, Any],
#     ) -> List[Dict]:
#         """Executes the action"""

#         PROFILE_DB_NAME = os.environ.get("PROFILE_DB_NAME", "rasa")
#         PROFILE_DB_URL = os.environ.get("PROFILE_DB_URL", f"sqlite:///{PROFILE_DB_NAME}.db")
#         ENGINE = sa.create_engine(PROFILE_DB_URL)
#         print('ENGINE')
#         print(ENGINE)
#         create_database_rasa(ENGINE, PROFILE_DB_NAME)

#         rasa_db = rasaDB(ENGINE)
#         print(rasa_db)
#         print(rasa_db.check_conversation_id_exists(tracker.sender_id))
#         demo = rasa_db.set_conversation_id(tracker.sender_id, tracker.latest_message['intent'].get('name'))
#         print(demo)

        
        # print("slots values are ", type(ack[2]))
        # SlotsFromDB = json.loads(ack[2])
        # print(type(SlotsFromDB))
        # print(SlotsFromDB)
        # phone = SlotsFromDB["phone_number"]
        # ack = SlotsFromDB["account_number"]
        # crdnum = SlotsFromDB["card_number"]
        # print("phone number From DB is ", phone)